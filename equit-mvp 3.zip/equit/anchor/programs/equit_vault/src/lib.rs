// EQUIT Vault — Anchor program skeleton (reference architecture)
//
// This is the conceptual on-chain design the MVP's off-chain risk engine
// (lib/risk/riskEngine.ts) mirrors. It is NOT compiled or deployed as part
// of this build — the shipped MVP runs its vault logic client-side in
// clearly-labeled DEMO MODE (see lib/vault/vaultService.ts) so the app is
// honest about what is live vs. simulated (see spec section 15).
//
// To take this to a real devnet deployment: set up the Anchor workspace
// (anchor init), fill in CPI calls to an SPL Token program for USDC
// transfers and to Pyth's on-chain price accounts for oracle reads, then
// point NEXT_PUBLIC_SOLANA_RPC_URL / program ID at the deployed instance.

use anchor_lang::prelude::*;

declare_id!("Eq1tVaU1t111111111111111111111111111111111");

#[program]
pub mod equit_vault {
    use super::*;

    pub fn initialize_vault(ctx: Context<InitializeVault>, max_ltv_bps: u16) -> Result<()> {
        let vault = &mut ctx.accounts.vault;
        vault.owner = ctx.accounts.owner.key();
        vault.debt_usdc = 0;
        vault.max_ltv_bps = max_ltv_bps;
        vault.protection_enabled = false;
        vault.trigger_health = 60;
        vault.target_health = 70;
        Ok(())
    }

    pub fn deposit_collateral(ctx: Context<VaultAction>, amount: u64) -> Result<()> {
        // CPI: transfer tokenized-equity SPL tokens from owner -> vault ATA.
        // Update vault.collateral_amounts[asset] += amount.
        msg!("deposit_collateral: {} (reference impl)", amount);
        Ok(())
    }

    pub fn borrow_usdc(ctx: Context<VaultAction>, amount: u64) -> Result<()> {
        // 1. Read Pyth price accounts for each collateral asset.
        // 2. Recompute risk-adjusted collateral + max LTV (mirrors
        //    lib/risk/riskEngine.ts::runRiskEngine).
        // 3. Require new debt / risk-adjusted collateral <= max_ltv_bps.
        // 4. CPI: transfer USDC from protocol vault -> owner.
        let vault = &mut ctx.accounts.vault;
        vault.debt_usdc = vault
            .debt_usdc
            .checked_add(amount)
            .ok_or(EquitError::MathOverflow)?;
        Ok(())
    }

    pub fn repay_usdc(ctx: Context<VaultAction>, amount: u64) -> Result<()> {
        let vault = &mut ctx.accounts.vault;
        vault.debt_usdc = vault.debt_usdc.saturating_sub(amount);
        Ok(())
    }

    pub fn withdraw_collateral(ctx: Context<VaultAction>, amount: u64) -> Result<()> {
        // Require projected LTV after withdrawal <= max_ltv_bps before
        // releasing collateral back to the owner.
        msg!("withdraw_collateral: {} (reference impl)", amount);
        Ok(())
    }

    pub fn set_protection_rules(
        ctx: Context<VaultAction>,
        trigger_health: u8,
        target_health: u8,
        enabled: bool,
    ) -> Result<()> {
        let vault = &mut ctx.accounts.vault;
        vault.trigger_health = trigger_health;
        vault.target_health = target_health;
        vault.protection_enabled = enabled;
        Ok(())
    }

    pub fn execute_protection(ctx: Context<VaultAction>) -> Result<()> {
        // Permissionless keeper instruction: recompute health on-chain via
        // Pyth; if below trigger_health, reduce debt or collateral toward
        // target_health following the same priority order as
        // lib/vault/vaultService.ts::simulateProtectionTrigger.
        msg!("execute_protection (reference impl)");
        Ok(())
    }
}

#[account]
pub struct Vault {
    pub owner: Pubkey,
    pub debt_usdc: u64,
    pub max_ltv_bps: u16, // basis points, e.g. 5500 = 55%
    pub protection_enabled: bool,
    pub trigger_health: u8,
    pub target_health: u8,
}

#[derive(Accounts)]
pub struct InitializeVault<'info> {
    #[account(init, payer = owner, space = 8 + 32 + 8 + 2 + 1 + 1 + 1)]
    pub vault: Account<'info, Vault>,
    #[account(mut)]
    pub owner: Signer<'info>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct VaultAction<'info> {
    #[account(mut, has_one = owner)]
    pub vault: Account<'info, Vault>,
    pub owner: Signer<'info>,
}

#[error_code]
pub enum EquitError {
    #[msg("Requested amount exceeds current borrowing power.")]
    ExceedsBorrowingPower,
    #[msg("Withdrawal would exceed maximum permitted LTV.")]
    ExceedsMaxLtv,
    #[msg("Price feed is stale.")]
    StaleOracle,
    #[msg("Math overflow.")]
    MathOverflow,
}
