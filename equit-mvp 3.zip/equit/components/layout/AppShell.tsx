"use client";

import { ReactNode } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import clsx from "clsx";
import { LogoWordmark } from "@/components/ui/Logo";
import { ConnectButton } from "@/components/wallet/ConnectButton";
import { Toaster } from "@/components/ui/Toaster";

const NAV_ITEMS = [
  { href: "/dashboard", label: "Dashboard" },
  { href: "/vault", label: "Vault" },
  { href: "/borrow", label: "Borrow" },
  { href: "/protect", label: "Protect" },
  { href: "/simulate", label: "Simulate" },
  { href: "/activity", label: "Activity" },
];

export function AppShell({ children }: { children: ReactNode }) {
  const pathname = usePathname();

  return (
    <div className="min-h-screen bg-ink-50">
      <div className="mx-auto flex max-w-7xl">
        {/* Desktop sidebar */}
        <aside className="hidden md:flex md:w-60 md:flex-col md:fixed md:inset-y-0 border-r border-ink-100 bg-white px-5 py-6">
          <Link href="/dashboard" className="mb-8 px-1">
            <LogoWordmark />
          </Link>
          <nav className="flex flex-1 flex-col gap-1">
            {NAV_ITEMS.map((item) => {
              const active = pathname?.startsWith(item.href);
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  className={clsx(
                    "rounded-lg px-3 py-2 text-sm font-medium transition-colors",
                    active ? "bg-brand-50 text-brand-700" : "text-ink-500 hover:bg-ink-50 hover:text-ink-900"
                  )}
                >
                  {item.label}
                </Link>
              );
            })}
          </nav>
          <Link
            href="/settings"
            className={clsx(
              "rounded-lg px-3 py-2 text-sm font-medium",
              pathname?.startsWith("/settings") ? "bg-brand-50 text-brand-700" : "text-ink-400 hover:bg-ink-50"
            )}
          >
            Settings
          </Link>
        </aside>

        <div className="flex-1 md:ml-60">
          {/* Header */}
          <header className="sticky top-0 z-10 flex items-center justify-between border-b border-ink-100 bg-white/80 backdrop-blur px-4 py-3 md:px-8">
            <Link href="/dashboard" className="md:hidden">
              <LogoWordmark />
            </Link>
            <div className="hidden md:block" />
            <ConnectButton />
          </header>

          <main className="px-4 py-6 md:px-8 md:py-8 pb-24 md:pb-8">{children}</main>
        </div>
      </div>

      {/* Mobile bottom nav */}
      <nav className="fixed bottom-0 inset-x-0 z-10 flex md:hidden items-center justify-around border-t border-ink-100 bg-white/95 backdrop-blur px-2 py-2">
        {NAV_ITEMS.slice(0, 5).map((item) => {
          const active = pathname?.startsWith(item.href);
          return (
            <Link
              key={item.href}
              href={item.href}
              className={clsx(
                "flex flex-1 flex-col items-center gap-0.5 rounded-lg py-1.5 text-[11px] font-medium",
                active ? "text-brand-700" : "text-ink-400"
              )}
            >
              <span
                className={clsx(
                  "h-1.5 w-1.5 rounded-full mb-0.5",
                  active ? "bg-brand-600" : "bg-transparent"
                )}
              />
              {item.label}
            </Link>
          );
        })}
      </nav>
      <Toaster />
    </div>
  );
}
