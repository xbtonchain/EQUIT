"use client";

import { useMemo, useState } from "react";
import { useRiskSnapshot, useVaultStore } from "@/store/useVaultStore";
import { runRiskEngine, suggestCollateralAllocation } from "@/lib/risk/riskEngine";
import { ASSET_META } from "@/lib/demo/fixtures";
import { Button } from "@/components/ui/Button";
import { RiskBadge } from "@/components/ui/Badge";

type Step = "amount" | "review" | "done";

export function BorrowFlow() {
  const [step, setStep] = useState<Step>("amount");
  const [amount, setAmount] = useState(8000);
  const vault = useVaultStore((s) => s.vault);
  const prices = useVaultStore((s) => s.prices);
  const marketStatuses = useVaultStore((s) => s.marketStatuses);
  const borrowAction = useVaultStore((s) => s.borrow);
  const lastError = useVaultStore((s) => s.lastError);
  const clearError = useVaultStore((s) => s.clearError);

  const current = useRiskSnapshot();

  const projected = useMemo(() => {
    return runRiskEngine({
      holdings: vault.collateral,
      prices,
      debtUsdc: vault.debtUsdc + amount,
      maxLtv: vault.maxLtv,
      marketStatuses,
    });
  }, [vault, prices, amount, marketStatuses]);

  const allocation = useMemo(
    () =>
      suggestCollateralAllocation(
        { holdings: vault.collateral, prices, debtUsdc: vault.debtUsdc, maxLtv: vault.maxLtv, marketStatuses },
        amount
      ),
    [vault, prices, amount, marketStatuses]
  );

  if (step === "done") {
    return (
      <div className="rounded-xl2 border border-ink-100 bg-white p-8 text-center shadow-card">
        <div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-full bg-safe/10 text-safe text-2xl">
          ✓
        </div>
        <h3 className="text-lg font-semibold text-ink-900">Borrow confirmed</h3>
        <p className="mt-1 text-sm text-ink-500">
          ${amount.toLocaleString()} USDC has been added to your available balance.
        </p>
        <Button className="mt-6" onClick={() => setStep("amount")}>
          Borrow again
        </Button>
      </div>
    );
  }

  if (step === "review") {
    return (
      <div className="rounded-xl2 border border-ink-100 bg-white p-6 shadow-card">
        <h3 className="text-sm font-semibold text-ink-900">Review borrowing</h3>

        <div className="mt-4 space-y-3 text-sm">
          <Row label="Borrow" value={`$${amount.toLocaleString()} USDC`} />
          <Row label="Collateral" value={`$${current.portfolioValue.toLocaleString(undefined, { maximumFractionDigits: 0 })}`} />
          <Row label="New LTV" value={`${(projected.ltv * 100).toFixed(0)}%`} />
          <div className="flex items-center justify-between">
            <span className="text-ink-400">Vault Health</span>
            <RiskBadge level={projected.health.level} />
          </div>
        </div>

        <div className="mt-5 rounded-lg bg-ink-50 p-4">
          <p className="text-xs font-medium text-ink-500 mb-2">How should we collateralize this?</p>
          {allocation.map((a) => (
            <div key={a.ticker} className="flex justify-between text-sm py-0.5">
              <span className="text-ink-600">{ASSET_META[a.ticker].underlying}</span>
              <span className="tabular-nums font-medium">${a.usdc.toLocaleString()}</span>
            </div>
          ))}
          <p className="mt-2 text-xs text-ink-400">
            This allocation produces a lower modeled concentration risk. You can override it before confirming.
          </p>
        </div>

        {lastError && (
          <p className="mt-4 rounded-lg bg-critical/10 px-3 py-2.5 text-sm text-critical">{lastError}</p>
        )}

        <div className="mt-6 flex gap-3">
          <Button variant="secondary" onClick={() => setStep("amount")}>
            Back
          </Button>
          <Button
            className="flex-1"
            onClick={() => {
              clearError();
              borrowAction(amount);
              const err = useVaultStore.getState().lastError;
              if (!err) setStep("done");
            }}
          >
            Confirm borrow
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="rounded-xl2 border border-ink-100 bg-white p-6 shadow-card">
      <h3 className="text-sm font-semibold text-ink-900">How much do you need?</h3>

      <div className="mt-3 flex items-baseline gap-1">
        <span className="text-2xl font-semibold text-ink-400">$</span>
        <input
          type="number"
          value={amount}
          onChange={(e) => setAmount(Number(e.target.value) || 0)}
          className="w-full bg-transparent text-4xl font-semibold tabular-nums text-ink-900 outline-none"
        />
      </div>

      <input
        type="range"
        min={0}
        max={Math.max(1, Math.round(current.availableLiquidity))}
        value={Math.min(amount, Math.round(current.availableLiquidity))}
        onChange={(e) => setAmount(Number(e.target.value))}
        className="mt-4 w-full accent-brand-600"
      />

      <div className="mt-4 space-y-3 text-sm border-t border-ink-100 pt-4">
        <Row label="Available" value={`$${current.availableLiquidity.toLocaleString(undefined, { maximumFractionDigits: 0 })}`} />
        <Row label="Estimated LTV" value={`${(projected.ltv * 100).toFixed(0)}%`} />
        <div className="flex items-center justify-between">
          <span className="text-ink-400">Vault Health</span>
          <RiskBadge level={projected.health.level} />
        </div>
        <Row label="Interest" value="4.25%" />
      </div>

      <Button
        className="mt-6 w-full"
        disabled={amount <= 0 || amount > current.availableLiquidity}
        onClick={() => setStep("review")}
      >
        Continue
      </Button>
      {amount > current.availableLiquidity && (
        <p className="mt-2 text-xs text-critical">
          Borrow unavailable. Your requested amount exceeds your current borrowing power.
        </p>
      )}
    </div>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between">
      <span className="text-ink-400">{label}</span>
      <span className="font-medium tabular-nums text-ink-900">{value}</span>
    </div>
  );
}
