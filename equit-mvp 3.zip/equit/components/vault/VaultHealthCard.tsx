import { VaultHealthResult } from "@/lib/types";
import { RiskBadge } from "@/components/ui/Badge";

export function VaultHealthCard({ health }: { health: VaultHealthResult }) {
  return (
    <div className="rounded-xl2 border border-ink-100 bg-white p-6 shadow-card">
      <div className="flex items-center justify-between">
        <span className="text-sm font-medium text-ink-500">Vault Health</span>
        <RiskBadge level={health.level} />
      </div>
      <div className="mt-2 text-4xl font-semibold tabular-nums text-ink-900">
        {health.score} <span className="text-lg font-normal text-ink-400">/ 100</span>
      </div>

      <div className="mt-5 space-y-2.5 border-t border-ink-100 pt-4">
        <FactorRow label="LTV" value={health.breakdown.ltv} />
        <FactorRow label="Diversification" value={health.breakdown.diversification} />
        <FactorRow label="Oracle" value={health.breakdown.oracle} />
        <FactorRow label="Liquidity" value={health.breakdown.liquidity} />
      </div>
    </div>
  );
}

function FactorRow({ label, value }: { label: string; value: string }) {
  const good = ["Healthy", "Good", "High"].includes(value);
  return (
    <div className="flex items-center justify-between text-sm">
      <span className="text-ink-400">{label}</span>
      <span className={good ? "font-medium text-safe" : "font-medium text-warning"}>{value}</span>
    </div>
  );
}
