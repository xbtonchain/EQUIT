export function LTVMeter({ ltv, maxLtv }: { ltv: number; maxLtv: number }) {
  const pct = Math.max(0, Math.min(1, ltv / maxLtv));
  return (
    <div className="w-full">
      <div className="relative h-2 w-full rounded-full bg-ink-100">
        <div
          className="absolute inset-y-0 left-0 rounded-full bg-brand-500"
          style={{ width: `${pct * 100}%` }}
        />
        <div
          className="absolute -top-1 h-4 w-4 -translate-x-1/2 rounded-full border-2 border-white bg-brand-600 shadow"
          style={{ left: `${pct * 100}%` }}
        />
      </div>
      <div className="mt-1.5 flex justify-between text-xs text-ink-400">
        <span>0%</span>
        <span>{Math.round(maxLtv * 100)}%</span>
      </div>
    </div>
  );
}
