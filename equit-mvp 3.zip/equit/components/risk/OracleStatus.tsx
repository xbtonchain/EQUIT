import { PriceQuote } from "@/lib/types";

function timeAgo(iso: string) {
  const seconds = Math.max(0, Math.round((Date.now() - new Date(iso).getTime()) / 1000));
  if (seconds < 60) return `${seconds}s ago`;
  return `${Math.round(seconds / 60)}m ago`;
}

export function OracleStatus({ quote }: { quote: PriceQuote }) {
  return (
    <div className="rounded-xl2 border border-ink-100 bg-white p-5 shadow-card">
      <div className="flex items-center justify-between text-sm font-medium text-ink-500">
        <span>Market data</span>
        <span className="text-xs text-ink-300 uppercase tracking-wide">
          {quote.source === "pyth" ? "Pyth" : "Pyth (demo feed)"}
        </span>
      </div>

      <div className="mt-3 flex items-center gap-2">
        <span
          className={`h-2 w-2 rounded-full ${quote.isStale ? "bg-warning" : "bg-safe"}`}
        />
        <span className="text-sm font-medium text-ink-900">
          {quote.isStale ? "Degraded" : "Healthy"}
        </span>
      </div>

      <div className="mt-4 grid grid-cols-3 gap-2 text-sm">
        <div>
          <div className="text-xs text-ink-400">Price</div>
          <div className="font-medium tabular-nums">${quote.price.toFixed(2)}</div>
        </div>
        <div>
          <div className="text-xs text-ink-400">Updated</div>
          <div className="font-medium">{timeAgo(quote.updatedAtIso)}</div>
        </div>
        <div>
          <div className="text-xs text-ink-400">Confidence</div>
          <div className="font-medium capitalize">{quote.confidence}</div>
        </div>
      </div>

      {quote.isStale && (
        <div className="mt-4 rounded-lg bg-warning/10 px-3 py-2.5 text-xs text-warning">
          Oracle protection — price feed is stale. New borrowing is temporarily disabled.
        </div>
      )}
    </div>
  );
}
