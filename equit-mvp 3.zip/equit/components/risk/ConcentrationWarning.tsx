export function ConcentrationWarning({ message }: { message: string }) {
  return (
    <div className="rounded-xl2 border border-warning/20 bg-warning/5 px-4 py-3 text-sm text-warning">
      <span className="font-medium">Concentration warning. </span>
      {message}
    </div>
  );
}
