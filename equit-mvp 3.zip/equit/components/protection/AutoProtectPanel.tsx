"use client";

import { useState } from "react";
import { useVaultStore } from "@/store/useVaultStore";
import { Button } from "@/components/ui/Button";

export function AutoProtectPanel() {
  const protection = useVaultStore((s) => s.vault.protection);
  const setProtection = useVaultStore((s) => s.setProtection);
  const [trigger, setTrigger] = useState(protection.triggerHealth);
  const [target, setTarget] = useState(protection.targetHealth);
  const [action, setAction] = useState<"repay" | "reduce_collateral">(protection.action);
  const [showPreview, setShowPreview] = useState(false);

  if (protection.enabled) {
    return (
      <div className="rounded-xl2 border border-ink-100 bg-white p-6 shadow-card">
        <div className="flex items-center justify-between">
          <span className="text-sm font-medium text-ink-500">Auto-Protect</span>
          <span className="inline-flex items-center gap-1.5 rounded-full bg-safe/10 px-2.5 py-1 text-xs font-semibold text-safe">
            <span className="h-1.5 w-1.5 rounded-full bg-safe" /> ON
          </span>
        </div>
        <div className="mt-4 grid grid-cols-2 gap-4 text-sm">
          <div>
            <div className="text-xs text-ink-400">Trigger</div>
            <div className="font-medium tabular-nums">{protection.triggerHealth}</div>
          </div>
          <div>
            <div className="text-xs text-ink-400">Target Health</div>
            <div className="font-medium tabular-nums">{protection.targetHealth}</div>
          </div>
        </div>
        <Button
          variant="secondary"
          className="mt-5"
          onClick={() => setProtection({ ...protection, enabled: false })}
        >
          Disable protection
        </Button>
      </div>
    );
  }

  return (
    <div className="rounded-xl2 border border-ink-100 bg-white p-6 shadow-card">
      <h3 className="text-sm font-semibold text-ink-900">Protect your vault</h3>
      <p className="mt-1 text-xs text-ink-400">
        Configure a rule that automatically reduces risk if your Vault Health falls too low.
      </p>

      <div className="mt-5 space-y-4 text-sm">
        <div>
          <label className="text-ink-500">Trigger — Vault Health falls below</label>
          <input
            type="number"
            value={trigger}
            onChange={(e) => setTrigger(Number(e.target.value))}
            className="mt-1 w-full rounded-lg border border-ink-200 px-3 py-2"
          />
        </div>
        <div>
          <label className="text-ink-500">Action</label>
          <select
            value={action}
            onChange={(e) => setAction(e.target.value as "repay" | "reduce_collateral")}
            className="mt-1 w-full rounded-lg border border-ink-200 px-3 py-2"
          >
            <option value="repay">Repay debt</option>
            <option value="reduce_collateral">Reduce collateral exposure</option>
          </select>
        </div>
        <div>
          <label className="text-ink-500">Target Health</label>
          <input
            type="number"
            value={target}
            onChange={(e) => setTarget(Number(e.target.value))}
            className="mt-1 w-full rounded-lg border border-ink-200 px-3 py-2"
          />
        </div>
      </div>

      {!showPreview ? (
        <Button className="mt-6 w-full" onClick={() => setShowPreview(true)}>
          Preview protection
        </Button>
      ) : (
        <div className="mt-5 rounded-lg bg-ink-50 p-4 text-sm">
          <p className="font-medium text-ink-900">If Vault Health falls to {trigger}:</p>
          <p className="mt-1 text-ink-500">EQUIT will attempt to restore it to {target}.</p>
          <p className="mt-3 text-xs font-medium text-ink-500">Priority</p>
          <ol className="mt-1 list-decimal pl-4 text-xs text-ink-500 space-y-0.5">
            <li>Available USDC</li>
            <li>User-defined protection liquidity</li>
            <li>Collateral reduction if configured</li>
          </ol>
          <Button
            className="mt-4 w-full"
            onClick={() =>
              setProtection({ enabled: true, triggerHealth: trigger, targetHealth: target, action })
            }
          >
            Enable Auto-Protect
          </Button>
        </div>
      )}
    </div>
  );
}
