"use client";

import { useMemo, useState } from "react";
import { useVaultStore } from "@/store/useVaultStore";
import { runRiskEngine } from "@/lib/risk/riskEngine";
import * as vaultService from "@/lib/vault/vaultService";
import { ASSET_META, demoBasePrices } from "@/lib/demo/fixtures";
import { AssetTicker } from "@/lib/types";
import { RiskBadge } from "@/components/ui/Badge";
import { Button } from "@/components/ui/Button";

const TICKERS = Object.keys(demoBasePrices) as AssetTicker[];

export function ScenarioSimulator() {
  const vault = useVaultStore((s) => s.vault);
  const prices = useVaultStore((s) => s.prices);
  const marketStatuses = useVaultStore((s) => s.marketStatuses);
  const [shocks, setShocks] = useState<Record<AssetTicker, number>>({
    NVDAx: 0,
    AAPLx: 0,
    SPYx: 0,
    TSLAx: 0,
  });
  const [additionalBorrow, setAdditionalBorrow] = useState(0);
  const [protectionResult, setProtectionResult] = useState<string | null>(null);

  const shockedPrices = useMemo(() => {
    const out = { ...prices };
    TICKERS.forEach((t) => {
      const base = prices[t]?.price ?? demoBasePrices[t];
      out[t] = { ...out[t], price: base * (1 + shocks[t] / 100) };
    });
    return out;
  }, [prices, shocks]);

  const baseline = useMemo(
    () =>
      runRiskEngine({
        holdings: vault.collateral,
        prices,
        debtUsdc: vault.debtUsdc,
        maxLtv: vault.maxLtv,
        marketStatuses,
      }),
    [vault, prices, marketStatuses]
  );

  const projected = useMemo(
    () =>
      runRiskEngine({
        holdings: vault.collateral,
        prices: shockedPrices,
        debtUsdc: vault.debtUsdc + additionalBorrow,
        maxLtv: vault.maxLtv,
        marketStatuses,
      }),
    [vault, shockedPrices, additionalBorrow, marketStatuses]
  );

  function runProtectionPreview() {
    const result = vaultService.simulateProtectionTrigger(
      { ...vault, debtUsdc: vault.debtUsdc + additionalBorrow },
      { prices: shockedPrices, marketStatuses }
    );
    setProtectionResult(
      result.triggered
        ? `${result.note} Debt would be reduced from $${(vault.debtUsdc + additionalBorrow).toLocaleString()} to $${result.newDebtUsdc.toLocaleString()}.`
        : "Vault Health stays above your protection trigger — no action needed."
    );
  }

  return (
    <div className="space-y-6">
      <div className="rounded-xl2 border border-ink-100 bg-white p-6 shadow-card">
        <h3 className="text-sm font-semibold text-ink-900 mb-4">Market scenario</h3>
        <div className="space-y-5">
          {TICKERS.map((t) => (
            <div key={t}>
              <div className="flex items-center justify-between text-sm mb-1.5">
                <span className="font-medium text-ink-700">{ASSET_META[t].underlying}</span>
                <span className="tabular-nums text-ink-500">
                  ${prices[t]?.price.toFixed(2)} → ${shockedPrices[t]?.price.toFixed(2)}{" "}
                  <span className={shocks[t] < 0 ? "text-critical" : shocks[t] > 0 ? "text-safe" : "text-ink-400"}>
                    ({shocks[t] > 0 ? "+" : ""}
                    {shocks[t]}%)
                  </span>
                </span>
              </div>
              <input
                type="range"
                min={-60}
                max={30}
                value={shocks[t]}
                onChange={(e) => setShocks((s) => ({ ...s, [t]: Number(e.target.value) }))}
                className="w-full accent-brand-600"
              />
            </div>
          ))}
        </div>

        <div className="mt-6 border-t border-ink-100 pt-5">
          <label className="text-sm font-medium text-ink-700">Additional borrowing</label>
          <div className="mt-1.5 flex items-baseline gap-1 rounded-lg border border-ink-200 px-3 py-2">
            <span className="text-ink-400">$</span>
            <input
              type="number"
              value={additionalBorrow}
              onChange={(e) => setAdditionalBorrow(Number(e.target.value) || 0)}
              className="w-full bg-transparent tabular-nums outline-none"
            />
          </div>
        </div>
      </div>

      <div className="rounded-xl2 border border-ink-100 bg-white p-6 shadow-card">
        <h3 className="text-sm font-semibold text-ink-900 mb-4">Projected outcome</h3>
        <div className="grid grid-cols-2 gap-5 text-sm">
          <Metric
            label="Portfolio"
            from={`$${baseline.portfolioValue.toLocaleString(undefined, { maximumFractionDigits: 0 })}`}
            to={`$${projected.portfolioValue.toLocaleString(undefined, { maximumFractionDigits: 0 })}`}
          />
          <Metric
            label="LTV"
            from={`${(baseline.ltv * 100).toFixed(1)}%`}
            to={`${(projected.ltv * 100).toFixed(1)}%`}
          />
          <Metric
            label="Debt"
            from={`$${vault.debtUsdc.toLocaleString()}`}
            to={`$${(vault.debtUsdc + additionalBorrow).toLocaleString()}`}
          />
          <div>
            <div className="text-xs text-ink-400 mb-1">Vault Health</div>
            <div className="flex items-center gap-2">
              <span className="tabular-nums font-medium">
                {baseline.health.score} → {projected.health.score}
              </span>
              <RiskBadge level={projected.health.level} />
            </div>
          </div>
        </div>

        {vault.protection.enabled && (
          <div className="mt-5 border-t border-ink-100 pt-5">
            <Button variant="secondary" onClick={runProtectionPreview}>
              Preview Auto-Protect response
            </Button>
            {protectionResult && (
              <p className="mt-3 rounded-lg bg-brand-50 px-3 py-2.5 text-xs text-brand-700">
                {protectionResult}
              </p>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

function Metric({ label, from, to }: { label: string; from: string; to: string }) {
  return (
    <div>
      <div className="text-xs text-ink-400 mb-1">{label}</div>
      <div className="tabular-nums font-medium">
        {from} <span className="text-ink-300">→</span> {to}
      </div>
    </div>
  );
}
