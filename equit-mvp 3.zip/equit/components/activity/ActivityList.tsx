import { ActivityItem } from "@/lib/types";

const ICONS: Record<ActivityItem["type"], string> = {
  borrow: "↑",
  repay: "↓",
  deposit: "+",
  withdraw: "−",
  protection_triggered: "⚡",
  protection_enabled: "●",
};

export function ActivityList({ items }: { items: ActivityItem[] }) {
  return (
    <div className="rounded-xl2 border border-ink-100 bg-white shadow-card overflow-hidden">
      {items.map((item) => (
        <div
          key={item.id}
          className="flex items-center justify-between gap-4 border-b border-ink-50 px-5 py-4 last:border-0"
        >
          <div className="flex items-center gap-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-full bg-ink-50 text-sm text-ink-500">
              {ICONS[item.type]}
            </div>
            <div>
              <div className="text-sm font-medium text-ink-900">{item.label}</div>
              <div className="text-xs text-ink-400">
                {item.timestamp}
                {item.isDemo ? " · Demo" : ""}
              </div>
            </div>
          </div>
          <div className="text-sm font-medium tabular-nums text-ink-900">{item.amountLabel}</div>
        </div>
      ))}
    </div>
  );
}
