"use client";

import { useEffect } from "react";
import { useVaultStore } from "@/store/useVaultStore";

export function Toaster() {
  const toast = useVaultStore((s) => s.lastToast);
  const clearToast = useVaultStore((s) => s.clearToast);

  useEffect(() => {
    if (!toast) return;
    const id = setTimeout(() => clearToast(), 2800);
    return () => clearTimeout(id);
  }, [toast, clearToast]);

  if (!toast) return null;

  return (
    <div className="fixed bottom-20 md:bottom-6 left-1/2 z-50 -translate-x-1/2 rounded-full bg-ink-900 px-4 py-2.5 text-sm font-medium text-white shadow-lg">
      {toast}
    </div>
  );
}
