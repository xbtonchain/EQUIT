import clsx from "clsx";
import { RiskLevel } from "@/lib/types";

const LEVEL_STYLES: Record<RiskLevel, string> = {
  SAFE: "bg-safe/10 text-safe",
  WATCH: "bg-watch/10 text-yellow-700",
  WARNING: "bg-warning/10 text-warning",
  CRITICAL: "bg-critical/10 text-critical",
};

export function RiskBadge({ level }: { level: RiskLevel }) {
  return (
    <span
      className={clsx(
        "inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-semibold",
        LEVEL_STYLES[level]
      )}
    >
      <span
        className={clsx(
          "h-1.5 w-1.5 rounded-full",
          level === "SAFE" && "bg-safe",
          level === "WATCH" && "bg-watch",
          level === "WARNING" && "bg-warning",
          level === "CRITICAL" && "bg-critical"
        )}
      />
      {level}
    </span>
  );
}

export function DemoBadge() {
  return (
    <span className="inline-flex items-center gap-1.5 rounded-full bg-brand-50 px-2.5 py-1 text-xs font-medium text-brand-700 border border-brand-100">
      DEMO MODE
    </span>
  );
}
