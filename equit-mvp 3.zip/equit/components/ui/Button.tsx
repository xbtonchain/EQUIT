import { ButtonHTMLAttributes, forwardRef } from "react";
import clsx from "clsx";

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: "primary" | "secondary" | "ghost" | "danger";
  size?: "sm" | "md" | "lg";
}

export const Button = forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant = "primary", size = "md", ...props }, ref) => {
    return (
      <button
        ref={ref}
        className={clsx(
          "inline-flex items-center justify-center font-medium rounded-full transition-colors disabled:opacity-40 disabled:cursor-not-allowed",
          variant === "primary" && "bg-brand-600 text-white hover:bg-brand-700",
          variant === "secondary" && "bg-ink-100 text-ink-900 hover:bg-ink-200",
          variant === "ghost" && "bg-transparent text-ink-700 hover:bg-ink-100",
          variant === "danger" && "bg-critical text-white hover:opacity-90",
          size === "sm" && "px-3 py-1.5 text-sm",
          size === "md" && "px-5 py-2.5 text-sm",
          size === "lg" && "px-6 py-3.5 text-base",
          className
        )}
        {...props}
      />
    );
  }
);
Button.displayName = "Button";
