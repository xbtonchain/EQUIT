export function LogoMark({ className = "h-6 w-6", color = "#14121A" }: { className?: string; color?: string }) {
  return (
    <svg viewBox="0 0 100 100" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
      <path
        d="M30 22 L72 50 L30 78"
        stroke={color}
        strokeWidth="14"
        strokeLinecap="square"
        strokeLinejoin="miter"
      />
    </svg>
  );
}

export function LogoWordmark({ className = "" }: { className?: string }) {
  return (
    <span className={`inline-flex items-center gap-2 ${className}`}>
      <LogoMark className="h-5 w-5" />
      <span className="text-lg font-semibold tracking-tight text-ink-900">EQUIT</span>
    </span>
  );
}
