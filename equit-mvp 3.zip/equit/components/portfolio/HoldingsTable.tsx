import { ASSET_META } from "@/lib/demo/fixtures";
import { Holding, PriceQuote } from "@/lib/types";

export function HoldingsTable({
  holdings,
  prices,
  portfolioValue,
}: {
  holdings: Holding[];
  prices: Record<string, PriceQuote>;
  portfolioValue: number;
}) {
  return (
    <div className="rounded-xl2 border border-ink-100 bg-white shadow-card overflow-hidden">
      <div className="px-5 py-4 border-b border-ink-100">
        <h3 className="text-sm font-semibold text-ink-900">Your assets</h3>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <tbody>
            {holdings.map((h) => {
              const meta = ASSET_META[h.ticker];
              const quote = prices[h.ticker];
              const value = (quote?.price ?? 0) * h.quantity;
              const pct = portfolioValue > 0 ? (value / portfolioValue) * 100 : 0;
              return (
                <tr key={h.ticker} className="border-b border-ink-50 last:border-0">
                  <td className="px-5 py-3.5 whitespace-nowrap">
                    <div className="flex items-center gap-3">
                      <div className="flex h-8 w-8 items-center justify-center rounded-full bg-brand-100 text-xs font-semibold text-brand-700">
                        {meta.logoInitial}
                      </div>
                      <div>
                        <div className="font-medium text-ink-900">{meta.ticker}</div>
                        <div className="text-xs text-ink-400">{meta.name}</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-3 py-3.5 text-right tabular-nums whitespace-nowrap">
                    ${quote?.price.toFixed(2)}
                  </td>
                  <td
                    className={`px-3 py-3.5 text-right tabular-nums whitespace-nowrap text-xs ${
                      (quote?.change24hPct ?? 0) >= 0 ? "text-safe" : "text-critical"
                    }`}
                  >
                    {(quote?.change24hPct ?? 0) >= 0 ? "+" : ""}
                    {quote?.change24hPct.toFixed(2)}%
                  </td>
                  <td className="px-3 py-3.5 text-right font-medium tabular-nums whitespace-nowrap">
                    ${value.toLocaleString(undefined, { maximumFractionDigits: 0 })}
                  </td>
                  <td className="px-5 py-3.5 text-right text-ink-400 tabular-nums whitespace-nowrap">
                    {pct.toFixed(1)}%
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
