import { RiskEngineInputs, VaultState } from "@/lib/types";
import { runRiskEngine } from "@/lib/risk/riskEngine";

// This service centralizes the vault mutation logic so both the demo store
// and (eventually) an on-chain-backed store share one set of rules. Every
// action returns either a new VaultState or an error describing why the
// action is unsafe — never a silent no-op.

export interface VaultActionResult {
  ok: boolean;
  vault?: VaultState;
  error?: string;
}

export function borrow(
  vault: VaultState,
  amountUsdc: number,
  engineInputsBase: Omit<RiskEngineInputs, "holdings" | "debtUsdc" | "maxLtv">
): VaultActionResult {
  if (amountUsdc <= 0) return { ok: false, error: "Enter an amount greater than zero." };

  const current = runRiskEngine({
    ...engineInputsBase,
    holdings: vault.collateral,
    debtUsdc: vault.debtUsdc,
    maxLtv: vault.maxLtv,
  });

  if (amountUsdc > current.availableLiquidity) {
    return {
      ok: false,
      error:
        "Borrow unavailable. Your requested amount exceeds your current borrowing power.",
    };
  }

  const anyStale = Object.values(engineInputsBase.prices).some((p) => p.isStale);
  if (anyStale) {
    return {
      ok: false,
      error: "Market data unavailable. Borrowing is temporarily disabled.",
    };
  }

  return { ok: true, vault: { ...vault, debtUsdc: vault.debtUsdc + amountUsdc } };
}

export function repay(vault: VaultState, amountUsdc: number): VaultActionResult {
  if (amountUsdc <= 0) return { ok: false, error: "Enter an amount greater than zero." };
  const newDebt = Math.max(0, vault.debtUsdc - amountUsdc);
  return { ok: true, vault: { ...vault, debtUsdc: newDebt } };
}

export function withdraw(
  vault: VaultState,
  ticker: VaultState["collateral"][number]["ticker"],
  usdcValueToWithdraw: number,
  engineInputsBase: Omit<RiskEngineInputs, "holdings" | "debtUsdc" | "maxLtv">
): VaultActionResult {
  const holding = vault.collateral.find((h) => h.ticker === ticker);
  if (!holding) return { ok: false, error: "Asset not found in vault." };

  const price = engineInputsBase.prices[ticker]?.price ?? 0;
  const qtyToRemove = price > 0 ? usdcValueToWithdraw / price : 0;
  if (qtyToRemove > holding.quantity) {
    return { ok: false, error: "Withdrawal exceeds your deposited balance for this asset." };
  }

  const newCollateral = vault.collateral.map((h) =>
    h.ticker === ticker ? { ...h, quantity: h.quantity - qtyToRemove } : h
  );

  const projected = runRiskEngine({
    ...engineInputsBase,
    holdings: newCollateral,
    debtUsdc: vault.debtUsdc,
    maxLtv: vault.maxLtv,
  });

  if (projected.ltv > vault.maxLtv) {
    return {
      ok: false,
      error:
        "Withdrawal unavailable. This would push your vault above the maximum permitted LTV. Reduce debt or withdraw a smaller amount.",
    };
  }

  return { ok: true, vault: { ...vault, collateral: newCollateral } };
}

export function setProtection(
  vault: VaultState,
  rules: VaultState["protection"]
): VaultActionResult {
  return { ok: true, vault: { ...vault, protection: rules } };
}

// Simulates the Auto-Protect engine reacting to a health drop. Priority:
// 1) repay debt with a modeled "available USDC" buffer, 2) collateral
// reduction if configured. This is deliberately conservative and
// deterministic so the demo is legible.
export function simulateProtectionTrigger(
  vault: VaultState,
  engineInputsBase: Omit<RiskEngineInputs, "holdings" | "debtUsdc" | "maxLtv">
): { triggered: boolean; newDebtUsdc: number; note: string } {
  const before = runRiskEngine({
    ...engineInputsBase,
    holdings: vault.collateral,
    debtUsdc: vault.debtUsdc,
    maxLtv: vault.maxLtv,
  });

  if (!vault.protection.enabled || before.health.score > vault.protection.triggerHealth) {
    return { triggered: false, newDebtUsdc: vault.debtUsdc, note: "" };
  }

  // Binary-search a debt level that restores health to the target.
  let lo = 0;
  let hi = vault.debtUsdc;
  for (let i = 0; i < 24; i++) {
    const mid = (lo + hi) / 2;
    const test = runRiskEngine({
      ...engineInputsBase,
      holdings: vault.collateral,
      debtUsdc: mid,
      maxLtv: vault.maxLtv,
    });
    if (test.health.score < vault.protection.targetHealth) {
      hi = mid;
    } else {
      lo = mid;
    }
  }

  return {
    triggered: true,
    newDebtUsdc: Math.round(hi),
    note: `Protection triggered. Restoring Vault Health toward ${vault.protection.targetHealth}.`,
  };
}
