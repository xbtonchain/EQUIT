import { buildDemoPrices } from "@/lib/demo/fixtures";
import { AssetTicker, PriceQuote } from "@/lib/types";

// Pyth Hermes price feed IDs (mainnet equity/ETF feeds where available).
// These feed the risk engine directly — see lib/risk/riskEngine.ts — rather
// than being displayed as decoration. If a feed can't be reached (no
// network, feed not yet listed, devnet-only build), we fall back to the
// demo price service and mark the quote source as "demo" so the UI can be
// honest about it (see OracleStatus component).
const PYTH_FEED_IDS: Partial<Record<AssetTicker, string>> = {
  // Populate with real Hermes feed IDs for production use, e.g.:
  // NVDAx: "0xb1073854ed24cbc755dc527418f52b7d271f6b80..."
};

const HERMES_ENDPOINT = "https://hermes.pyth.network/v2/updates/price/latest";
const STALE_AFTER_SECONDS = 60;

async function fetchLivePrice(ticker: AssetTicker): Promise<PriceQuote | null> {
  const feedId = PYTH_FEED_IDS[ticker];
  if (!feedId) return null;

  try {
    const res = await fetch(`${HERMES_ENDPOINT}?ids[]=${feedId}`, {
      cache: "no-store",
    });
    if (!res.ok) return null;
    const data = await res.json();
    const parsed = data?.parsed?.[0];
    if (!parsed) return null;

    const priceInfo = parsed.price;
    const price = Number(priceInfo.price) * Math.pow(10, priceInfo.expo);
    const conf = Number(priceInfo.conf) * Math.pow(10, priceInfo.expo);
    const publishTime = priceInfo.publish_time as number;
    const ageSeconds = Date.now() / 1000 - publishTime;
    const confidencePct = price > 0 ? conf / price : 1;

    return {
      ticker,
      price,
      change24hPct: 0, // Hermes latest-price endpoint doesn't include 24h change
      confidence: confidencePct < 0.002 ? "high" : confidencePct < 0.01 ? "medium" : "low",
      updatedAtIso: new Date(publishTime * 1000).toISOString(),
      isStale: ageSeconds > STALE_AFTER_SECONDS,
      source: "pyth",
    };
  } catch {
    return null;
  }
}

export async function getPriceQuotes(
  tickers: AssetTicker[]
): Promise<Record<AssetTicker, PriceQuote>> {
  const demo = buildDemoPrices();
  const results = await Promise.all(
    tickers.map(async (ticker) => {
      const live = await fetchLivePrice(ticker);
      return [ticker, live ?? demo[ticker]] as const;
    })
  );
  return Object.fromEntries(results) as Record<AssetTicker, PriceQuote>;
}

export function isLiveFeedConfigured(ticker: AssetTicker): boolean {
  return Boolean(PYTH_FEED_IDS[ticker]);
}
