import { ASSET_META } from "@/lib/demo/fixtures";
import {
  AssetTicker,
  RiskEngineInputs,
  RiskEngineOutput,
  RiskFactorBreakdown,
  RiskLevel,
  VaultHealthResult,
} from "@/lib/types";

// Per-asset collateral factor: how much of an asset's market value counts
// toward risk-adjusted collateral. Lower factor = more conservative
// (higher perceived volatility / lower liquidity).
const COLLATERAL_FACTORS: Record<AssetTicker, number> = {
  SPYx: 0.9,
  AAPLx: 0.85,
  NVDAx: 0.75,
  TSLAx: 0.7,
};

const CONCENTRATION_WARNING_THRESHOLD = 0.4;

export function computePortfolioValue(inputs: RiskEngineInputs): number {
  return inputs.holdings.reduce((sum, h) => {
    const price = inputs.prices[h.ticker]?.price ?? 0;
    return sum + price * h.quantity;
  }, 0);
}

export function computeConcentration(
  inputs: RiskEngineInputs,
  portfolioValue: number
): { ticker: AssetTicker; pct: number }[] {
  if (portfolioValue <= 0) return [];
  return inputs.holdings
    .map((h) => {
      const price = inputs.prices[h.ticker]?.price ?? 0;
      return { ticker: h.ticker, pct: (price * h.quantity) / portfolioValue };
    })
    .sort((a, b) => b.pct - a.pct);
}

function computeRiskAdjustedCollateral(inputs: RiskEngineInputs): number {
  return inputs.holdings.reduce((sum, h) => {
    const price = inputs.prices[h.ticker]?.price ?? 0;
    const factor = COLLATERAL_FACTORS[h.ticker] ?? 0.6;
    const staleness = inputs.prices[h.ticker]?.isStale ? 0.8 : 1;
    return sum + price * h.quantity * factor * staleness;
  }, 0);
}

function levelFromScore(score: number): RiskLevel {
  if (score >= 80) return "SAFE";
  if (score >= 60) return "WATCH";
  if (score >= 40) return "WARNING";
  return "CRITICAL";
}

function computeHealth(
  ltv: number,
  maxLtv: number,
  concentration: { ticker: AssetTicker; pct: number }[],
  anyStale: boolean,
  availableLiquidity: number,
  portfolioValue: number
): VaultHealthResult {
  // LTV component: 100 at 0% LTV, 0 at or above maxLtv.
  const ltvScore = Math.max(0, Math.min(100, 100 * (1 - ltv / maxLtv)));

  // Diversification: penalize concentration above ~25% per asset.
  const topPct = concentration[0]?.pct ?? 0;
  const diversificationScore = Math.max(0, Math.min(100, 100 - Math.max(0, topPct - 0.25) * 200));

  // Oracle: binary-ish, degraded if any feed stale.
  const oracleScore = anyStale ? 40 : 100;

  // Liquidity: available liquidity relative to portfolio value.
  const liquidityRatio = portfolioValue > 0 ? availableLiquidity / portfolioValue : 0;
  const liquidityScore = Math.max(0, Math.min(100, liquidityRatio * 250));

  const score = Math.round(
    ltvScore * 0.45 + diversificationScore * 0.2 + oracleScore * 0.2 + liquidityScore * 0.15
  );

  const breakdown: RiskFactorBreakdown = {
    ltv: ltvScore >= 70 ? "Healthy" : ltvScore >= 40 ? "Elevated" : "Poor",
    diversification: diversificationScore >= 70 ? "Good" : diversificationScore >= 40 ? "Fair" : "Poor",
    oracle: oracleScore >= 80 ? "Healthy" : "Degraded",
    liquidity: liquidityScore >= 66 ? "High" : liquidityScore >= 33 ? "Medium" : "Low",
  };

  return { score: Math.max(0, Math.min(100, score)), level: levelFromScore(score), breakdown };
}

export function runRiskEngine(inputs: RiskEngineInputs): RiskEngineOutput {
  const portfolioValue = computePortfolioValue(inputs);
  const riskAdjustedCollateral = computeRiskAdjustedCollateral(inputs);
  const maxBorrowingPower = riskAdjustedCollateral * inputs.maxLtv;
  const availableLiquidity = Math.max(0, maxBorrowingPower - inputs.debtUsdc);
  const ltv = riskAdjustedCollateral > 0 ? inputs.debtUsdc / riskAdjustedCollateral : 0;
  const concentration = computeConcentration(inputs, portfolioValue);
  const anyStale = Object.values(inputs.prices).some((p) => p.isStale);

  const health = computeHealth(
    ltv,
    inputs.maxLtv,
    concentration,
    anyStale,
    availableLiquidity,
    portfolioValue
  );

  const top = concentration[0];
  const concentrationWarning =
    top && top.pct >= CONCENTRATION_WARNING_THRESHOLD
      ? `${Math.round(top.pct * 100)}% of your collateral is exposed to ${ASSET_META[top.ticker].underlying}. Diversifying collateral may improve your vault's risk profile.`
      : null;

  return {
    portfolioValue,
    riskAdjustedCollateral,
    maxBorrowingPower,
    availableLiquidity,
    ltv,
    health,
    concentration,
    concentrationWarning,
  };
}

// Suggests a collateral allocation for a target borrow amount, preferring
// assets with higher collateral factors and lower current concentration.
export function suggestCollateralAllocation(
  inputs: RiskEngineInputs,
  targetBorrowUsdc: number
): { ticker: AssetTicker; usdc: number }[] {
  const ranked = (Object.keys(COLLATERAL_FACTORS) as AssetTicker[])
    .filter((t) => inputs.holdings.some((h) => h.ticker === t))
    .sort((a, b) => COLLATERAL_FACTORS[b] - COLLATERAL_FACTORS[a]);

  const weights = [0.5, 0.3, 0.15, 0.05];
  return ranked.map((ticker, i) => ({
    ticker,
    usdc: Math.round(targetBorrowUsdc * (weights[i] ?? 0)),
  }));
}
