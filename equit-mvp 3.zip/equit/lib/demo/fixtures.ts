import {
  ActivityItem,
  AssetMeta,
  AssetTicker,
  Holding,
  MarketStatus,
  PriceQuote,
  ProtectionRules,
} from "@/lib/types";

// Single source of truth for demo-mode data. No component should hardcode
// prices, holdings, or activity — everything flows from here so the
// scenario can be changed in one place.

export const ASSET_META: Record<AssetTicker, AssetMeta> = {
  NVDAx: { ticker: "NVDAx", underlying: "NVDA", name: "NVIDIA", logoInitial: "N" },
  AAPLx: { ticker: "AAPLx", underlying: "AAPL", name: "Apple", logoInitial: "A" },
  SPYx: { ticker: "SPYx", underlying: "SPY", name: "S&P 500", logoInitial: "S" },
  TSLAx: { ticker: "TSLAx", underlying: "TSLA", name: "Tesla", logoInitial: "T" },
};

// Quantities chosen so portfolio value lands at the spec's $40,070 total
// at demo base prices below.
export const demoHoldings: Holding[] = [
  { ticker: "NVDAx", quantity: 101 }, // 101 * 182.41 ≈ 18,423
  { ticker: "AAPLx", quantity: 43.5 }, // ≈ 9,800
  { ticker: "SPYx", quantity: 13.4 }, // ≈ 7,640
  { ticker: "TSLAx", quantity: 16.9 }, // ≈ 4,210
];

export const demoBasePrices: Record<AssetTicker, number> = {
  NVDAx: 182.41,
  AAPLx: 225.29,
  SPYx: 570.15,
  TSLAx: 249.11,
};

export function buildDemoPrices(): Record<AssetTicker, PriceQuote> {
  const now = new Date().toISOString();
  const changes: Record<AssetTicker, number> = {
    NVDAx: 2.84,
    AAPLx: 0.61,
    SPYx: 0.42,
    TSLAx: -1.15,
  };
  const out = {} as Record<AssetTicker, PriceQuote>;
  (Object.keys(demoBasePrices) as AssetTicker[]).forEach((ticker) => {
    out[ticker] = {
      ticker,
      price: demoBasePrices[ticker],
      change24hPct: changes[ticker],
      confidence: "high",
      updatedAtIso: now,
      isStale: false,
      source: "demo",
    };
  });
  return out;
}

export function buildDemoMarketStatuses(): Record<AssetTicker, MarketStatus> {
  const out = {} as Record<AssetTicker, MarketStatus>;
  (Object.keys(demoBasePrices) as AssetTicker[]).forEach((ticker) => {
    out[ticker] = {
      ticker,
      underlyingMarket: "closed",
      tokenizedMarket: "open",
    };
  });
  return out;
}

export const demoDebtUsdc = 8000;
export const demoMaxLtv = 0.55;

export const demoProtection: ProtectionRules = {
  enabled: false,
  triggerHealth: 60,
  targetHealth: 70,
  action: "repay",
};

export const demoActivity: ActivityItem[] = [
  {
    id: "act-1",
    type: "borrow",
    label: "Borrowed",
    amountLabel: "+$8,000 USDC",
    timestamp: "Today",
    isDemo: true,
  },
  {
    id: "act-2",
    type: "deposit",
    label: "Deposited",
    amountLabel: "$20,000 NVDAx",
    timestamp: "Today",
    isDemo: true,
  },
  {
    id: "act-3",
    type: "repay",
    label: "Repayment",
    amountLabel: "-$2,000 USDC",
    timestamp: "Yesterday",
    isDemo: true,
  },
  {
    id: "act-4",
    type: "withdraw",
    label: "Withdrawn",
    amountLabel: "$4,000 AAPLx",
    timestamp: "Yesterday",
    isDemo: true,
  },
];
