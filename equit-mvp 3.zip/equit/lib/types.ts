// Central domain types. Every service/component should import from here
// rather than redefining shapes locally.

export type AssetTicker = "NVDAx" | "AAPLx" | "SPYx" | "TSLAx";

export type MarketSessionStatus =
  | "open"
  | "closed"
  | "pre-market"
  | "after-hours"
  | "overnight";

export interface AssetMeta {
  ticker: AssetTicker;
  underlying: string; // e.g. "NVDA"
  name: string; // e.g. "NVIDIA"
  logoInitial: string;
}

export interface PriceQuote {
  ticker: AssetTicker;
  price: number;
  change24hPct: number;
  confidence: "high" | "medium" | "low";
  updatedAtIso: string;
  isStale: boolean;
  source: "pyth" | "demo";
}

export interface MarketStatus {
  ticker: AssetTicker;
  underlyingMarket: MarketSessionStatus;
  tokenizedMarket: MarketSessionStatus;
}

export interface Holding {
  ticker: AssetTicker;
  quantity: number;
}

export type RiskLevel = "SAFE" | "WATCH" | "WARNING" | "CRITICAL";

export interface RiskFactorBreakdown {
  ltv: "Healthy" | "Elevated" | "Poor";
  diversification: "Good" | "Fair" | "Poor";
  oracle: "Healthy" | "Degraded";
  liquidity: "High" | "Medium" | "Low";
}

export interface VaultHealthResult {
  score: number; // 0-100
  level: RiskLevel;
  breakdown: RiskFactorBreakdown;
}

export interface VaultState {
  owner: string; // wallet address or "demo"
  debtUsdc: number;
  collateral: Holding[];
  maxLtv: number; // e.g. 0.55
  protection: ProtectionRules;
  isDemo: boolean;
}

export interface ProtectionRules {
  enabled: boolean;
  triggerHealth: number; // e.g. 60
  targetHealth: number; // e.g. 70
  action: "repay" | "reduce_collateral";
}

export type ActivityType =
  | "borrow"
  | "repay"
  | "deposit"
  | "withdraw"
  | "protection_triggered"
  | "protection_enabled";

export interface ActivityItem {
  id: string;
  type: ActivityType;
  label: string;
  amountLabel: string;
  timestamp: string;
  isDemo: boolean;
  explorerUrl?: string;
}

export interface RiskEngineInputs {
  holdings: Holding[];
  prices: Record<AssetTicker, PriceQuote>;
  debtUsdc: number;
  maxLtv: number;
  marketStatuses: Record<AssetTicker, MarketStatus>;
}

export interface RiskEngineOutput {
  portfolioValue: number;
  riskAdjustedCollateral: number;
  maxBorrowingPower: number;
  availableLiquidity: number;
  ltv: number;
  health: VaultHealthResult;
  concentration: { ticker: AssetTicker; pct: number }[];
  concentrationWarning: string | null;
}
