# EQUIT

**Unlock liquidity without selling your stocks.**

EQUIT turns tokenized equities on Solana into programmable collateral. Connect a wallet,
see your eligible portfolio, discover how much liquidity you can safely unlock, borrow
USDC, monitor Vault Health, simulate market scenarios, and enable Auto-Protect — a rule
that automatically de-risks your vault if things move against you.

Built for the Solana Stocklana hackathon.

---

## 1. Install

```bash
npm install
```

> This repository was authored in a sandboxed environment without network access, so
> `npm install` / `npm run build` have **not** been run or verified here. Run both
> locally or let Vercel run them on deploy — see "Build verification" below.

## 2. Environment variables

Copy `.env.example` to `.env.local` and fill in as needed:

```bash
cp .env.example .env.local
```

| Variable | Purpose | Default |
|---|---|---|
| `NEXT_PUBLIC_SOLANA_NETWORK` | `devnet` or `mainnet-beta` | `devnet` |
| `NEXT_PUBLIC_SOLANA_RPC_URL` | RPC endpoint for the chosen network | Solana public devnet RPC |
| `NEXT_PUBLIC_EQUIT_PROGRAM_ID` | Deployed Anchor program ID, once you deploy `anchor/` | empty |

No secrets or private keys are ever read client-side. Wallet connection is handled
entirely by `@solana/wallet-adapter-react` + Phantom.

## 3. Local development

```bash
npm run dev
```

Open `http://localhost:3000`. The app works fully **without a connected wallet** —
demo mode preloads a realistic portfolio ($40,070 across NVDAx/AAPLx/SPYx/TSLAx) so
every screen (dashboard, borrow, vault, protect, simulate, activity) is explorable
immediately. This is intentional: see `lib/demo/fixtures.ts`, the single source of
truth for demo data, and section 36 of the product spec this build follows.

Connecting Phantom shows a real wallet address, SOL balance, and network indicator,
but vault actions (borrow/repay/withdraw/protect) run against the client-side demo
vault store (`store/useVaultStore.ts`) rather than a deployed program, and are clearly
labeled **DEMO MODE** in the UI. See "Solana network configuration" below for what it
takes to go live.

## 4. Solana network configuration

The app defaults to **Solana Devnet**. To point at Mainnet, change only the two env
vars above — no code changes required (`components/wallet/WalletProvider.tsx` reads
them directly). Currently only the Phantom adapter is wired up
(`@solana/wallet-adapter-phantom`), kept as a standalone package rather than the
`@solana/wallet-adapter-wallets` aggregator so the install doesn't pull in every other
wallet's SDK (WalletConnect, Torus, Stellar, etc.). Add more standalone adapter
packages there if you want broader wallet support — note that many modern wallets
(Phantom included) also auto-register via the Wallet Standard, so `useWallet()` may
pick them up without an explicit adapter at all.

## 5. Pyth configuration

Price data flows through a single abstraction: `lib/pyth/priceService.ts`. It attempts
a live read from Pyth's public Hermes REST endpoint for any ticker with a feed ID
configured in `PYTH_FEED_IDS`, and falls back to the demo price service
(`lib/demo/fixtures.ts`) for anything unconfigured or unreachable — this is why the app
still works with no network access. To go live for a given asset, add its Hermes feed
ID to `PYTH_FEED_IDS` in that file. Price, confidence, and staleness all feed directly
into the risk engine (`lib/risk/riskEngine.ts`) — see the Oracle Status card in the UI
for what "stale" does to borrowing.

## 6. Smart contract configuration

`anchor/programs/equit_vault/src/lib.rs` is a **reference Anchor program skeleton**
describing the on-chain instruction set (`initialize_vault`, `deposit_collateral`,
`borrow_usdc`, `repay_usdc`, `withdraw_collateral`, `set_protection_rules`,
`execute_protection`) that mirrors the off-chain risk engine's math. It is not built,
tested, or deployed as part of this repo. To take it live:

```bash
cd anchor
anchor init  # if you haven't already scaffolded a workspace around this program
anchor build
anchor deploy --provider.cluster devnet
```

Then set `NEXT_PUBLIC_EQUIT_PROGRAM_ID` to the deployed program ID and wire
`lib/vault/vaultService.ts` to send real instructions instead of mutating client state.

## 7. Demo mode

Demo mode is the default experience and is safe to leave on for judging — see
`lib/demo/fixtures.ts` for the scenario (portfolio composition, prices, starting debt,
activity history) and `lib/vault/vaultService.ts` for the transaction logic it runs
against. Every screen states clearly when something is simulated vs. live (`DEMO MODE`
badges, the Settings page, and the Oracle Status card's feed source label).

## 8. Vercel deployment

```bash
vercel
```

Or connect the repo in the Vercel dashboard. Set the environment variables from step 2
in the Vercel project settings before deploying. No server-side secrets are required
for demo mode or for Hermes's public REST endpoint.

### Build verification

Before shipping, run and confirm these succeed in an environment with network access:

```bash
npm install
npm run build
```

Fix any TypeScript errors surfaced by `next build` — the codebase is written in strict
TypeScript throughout (`tsconfig.json` has `"strict": true`), so a clean build should
mean no `any`-shaped surprises.

---

## Architecture

```
app/            Next.js App Router pages (one per nav item in the spec)
components/     UI grouped by domain (layout, wallet, portfolio, vault,
                borrowing, risk, protection, simulator, activity, ui)
lib/
  types.ts      Shared domain types — single source of truth for shapes
  demo/         Centralized demo/fixture data (no hardcoded values in components)
  risk/         Risk engine: LTV, Vault Health, concentration, collateral suggestion
  pyth/         Price service abstraction (live Hermes + demo fallback)
  vault/        Vault action logic (borrow/repay/withdraw/protect), demo-aware
  solana/       (reserved for on-chain program client helpers)
store/          Client state (zustand) wiring the demo vault + risk engine together
anchor/         Reference Anchor program skeleton (see section 6 above)
```

## Product principles this build follows

Simple, financially credible, functional, risk-aware, minimal, premium, responsive,
Solana-native. See the full product spec for details — the visual language is a
Phantom-inspired purple-on-white palette (`tailwind.config.ts`), typography is Inter,
and the dashboard deliberately surfaces only Level 1/2 information (portfolio value,
available liquidity, Vault Health, LTV, debt, collateral) before anything else.

## Disclaimers

EQUIT is a hackathon MVP. It does not offer guaranteed protection, guaranteed returns,
risk-free borrowing, or regulated lending, and interest rates shown are illustrative.
