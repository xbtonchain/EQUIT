import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        brand: {
          50: "#F5F3FF",
          100: "#EDE9FE",
          200: "#DDD6FE",
          300: "#C4B5FD",
          400: "#A78BFA",
          500: "#8B5CF6",
          600: "#7C3AED",
          700: "#6D28D9",
          800: "#5B21B6",
          900: "#4C1D95",
        },
        ink: {
          900: "#14121A",
          800: "#1E1B26",
          700: "#2B2733",
          500: "#585269",
          400: "#8B85A0",
          300: "#B8B3C7",
          200: "#E4E1EC",
          100: "#F0EEF6",
          50: "#F9F8FC",
        },
        safe: "#16A34A",
        watch: "#EAB308",
        warning: "#F97316",
        critical: "#DC2626",
      },
      fontFamily: {
        sans: ["Inter", "ui-sans-serif", "system-ui", "sans-serif"],
      },
      boxShadow: {
        card: "0 1px 2px rgba(20,18,26,0.04), 0 1px 12px rgba(20,18,26,0.04)",
      },
      borderRadius: {
        xl2: "1.25rem",
      },
    },
  },
  plugins: [],
};

export default config;
