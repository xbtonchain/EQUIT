"use client";

import { useMemo, useState } from "react";
import { AppShell } from "@/components/layout/AppShell";
import { useRiskSnapshot, useVaultStore } from "@/store/useVaultStore";
import { LTVMeter } from "@/components/vault/LTVMeter";
import { Button } from "@/components/ui/Button";
import { ASSET_META } from "@/lib/demo/fixtures";
import { runRiskEngine } from "@/lib/risk/riskEngine";
import { AssetTicker } from "@/lib/types";

export default function VaultPage() {
  const vault = useVaultStore((s) => s.vault);
  const prices = useVaultStore((s) => s.prices);
  const marketStatuses = useVaultStore((s) => s.marketStatuses);
  const risk = useRiskSnapshot();
  const repayAction = useVaultStore((s) => s.repay);
  const withdrawAction = useVaultStore((s) => s.withdraw);
  const lastError = useVaultStore((s) => s.lastError);
  const clearError = useVaultStore((s) => s.clearError);

  const [tab, setTab] = useState<"repay" | "withdraw" | "spend">("repay");
  const [repayAmount, setRepayAmount] = useState(2000);
  const [withdrawTicker, setWithdrawTicker] = useState<AssetTicker>("AAPLx");
  const [withdrawAmount, setWithdrawAmount] = useState(5000);
  const [sendAmount, setSendAmount] = useState(1000);

  const repayProjection = useMemo(
    () =>
      runRiskEngine({
        holdings: vault.collateral,
        prices,
        debtUsdc: Math.max(0, vault.debtUsdc - repayAmount),
        maxLtv: vault.maxLtv,
        marketStatuses,
      }),
    [vault, prices, repayAmount, marketStatuses]
  );

  const withdrawProjection = useMemo(() => {
    const price = prices[withdrawTicker]?.price ?? 0;
    const qtyRemove = price > 0 ? withdrawAmount / price : 0;
    const newHoldings = vault.collateral.map((h) =>
      h.ticker === withdrawTicker ? { ...h, quantity: Math.max(0, h.quantity - qtyRemove) } : h
    );
    return runRiskEngine({
      holdings: newHoldings,
      prices,
      debtUsdc: vault.debtUsdc,
      maxLtv: vault.maxLtv,
      marketStatuses,
    });
  }, [vault, prices, withdrawTicker, withdrawAmount, marketStatuses]);

  return (
    <AppShell>
      <div className="mx-auto max-w-5xl space-y-6">
        <h1 className="text-lg font-semibold text-ink-900">Vault</h1>

        <div className="grid gap-5 md:grid-cols-2">
          <div className="rounded-xl2 border border-ink-100 bg-white p-6 shadow-card">
            <span className="text-sm font-medium text-ink-500">Your borrowing power</span>
            <div className="mt-2 text-3xl font-semibold tabular-nums">
              ${risk.availableLiquidity.toLocaleString(undefined, { maximumFractionDigits: 0 })}
            </div>
            <p className="text-xs text-ink-400 mt-1">Available now</p>

            <div className="mt-5 grid grid-cols-2 gap-4 text-sm border-t border-ink-100 pt-4">
              <div>
                <div className="text-xs text-ink-400">Portfolio value</div>
                <div className="font-medium tabular-nums">
                  ${risk.portfolioValue.toLocaleString(undefined, { maximumFractionDigits: 0 })}
                </div>
              </div>
              <div>
                <div className="text-xs text-ink-400">Current debt</div>
                <div className="font-medium tabular-nums">${vault.debtUsdc.toLocaleString()}</div>
              </div>
              <div>
                <div className="text-xs text-ink-400">Current LTV</div>
                <div className="font-medium tabular-nums">{(risk.ltv * 100).toFixed(0)}%</div>
              </div>
              <div>
                <div className="text-xs text-ink-400">Maximum LTV</div>
                <div className="font-medium tabular-nums">{(vault.maxLtv * 100).toFixed(0)}%</div>
              </div>
            </div>
            <div className="mt-4">
              <LTVMeter ltv={risk.ltv} maxLtv={vault.maxLtv} />
            </div>
          </div>

          {/* Action panel */}
          <div className="rounded-xl2 border border-ink-100 bg-white p-6 shadow-card">
            <div className="flex gap-1 rounded-full bg-ink-50 p-1 text-sm">
              {(["repay", "withdraw", "spend"] as const).map((t) => (
                <button
                  key={t}
                  onClick={() => {
                    setTab(t);
                    clearError();
                  }}
                  className={`flex-1 rounded-full py-1.5 font-medium capitalize transition-colors ${
                    tab === t ? "bg-white shadow-card text-ink-900" : "text-ink-400"
                  }`}
                >
                  {t}
                </button>
              ))}
            </div>

            {tab === "repay" && (
              <div className="mt-5">
                <p className="text-xs text-ink-400 mb-1">Outstanding debt: ${vault.debtUsdc.toLocaleString()}</p>
                <AmountInput value={repayAmount} onChange={setRepayAmount} />
                <div className="mt-3 space-y-2 text-sm">
                  <Row label="Remaining debt" value={`$${Math.max(0, vault.debtUsdc - repayAmount).toLocaleString()}`} />
                  <Row label="New LTV" value={`${(repayProjection.ltv * 100).toFixed(0)}%`} />
                  <Row label="New Vault Health" value={`${repayProjection.health.score}`} />
                </div>
                <Button
                  className="mt-4 w-full"
                  disabled={repayAmount <= 0}
                  onClick={() => repayAction(repayAmount)}
                >
                  Repay
                </Button>
              </div>
            )}

            {tab === "withdraw" && (
              <div className="mt-5">
                <select
                  value={withdrawTicker}
                  onChange={(e) => setWithdrawTicker(e.target.value as AssetTicker)}
                  className="w-full rounded-lg border border-ink-200 px-3 py-2 text-sm mb-3"
                >
                  {vault.collateral.map((h) => (
                    <option key={h.ticker} value={h.ticker}>
                      {ASSET_META[h.ticker].ticker} — {ASSET_META[h.ticker].name}
                    </option>
                  ))}
                </select>
                <AmountInput value={withdrawAmount} onChange={setWithdrawAmount} />
                <div className="mt-3 space-y-2 text-sm">
                  <Row label="Current LTV" value={`${(risk.ltv * 100).toFixed(0)}%`} />
                  <Row label="After withdrawal" value={`${(withdrawProjection.ltv * 100).toFixed(0)}%`} />
                  <Row label="Vault Health" value={`${withdrawProjection.health.score}`} />
                </div>
                {lastError && tab === "withdraw" && (
                  <p className="mt-3 rounded-lg bg-critical/10 px-3 py-2.5 text-xs text-critical">{lastError}</p>
                )}
                <Button
                  className="mt-4 w-full"
                  disabled={withdrawAmount <= 0}
                  onClick={() => withdrawAction(withdrawTicker, withdrawAmount)}
                >
                  Confirm withdrawal
                </Button>
              </div>
            )}

            {tab === "spend" && (
              <div className="mt-5">
                <p className="text-xs text-ink-400 mb-1">
                  Available liquidity: ${risk.availableLiquidity.toLocaleString(undefined, { maximumFractionDigits: 0 })}
                </p>
                <AmountInput value={sendAmount} onChange={setSendAmount} />
                <div className="mt-4 grid grid-cols-2 gap-3">
                  <Button variant="secondary">Send USDC</Button>
                  <Button variant="secondary">Withdraw USDC</Button>
                </div>
                <p className="mt-3 text-xs text-ink-400">
                  In demo mode, sending USDC is simulated and does not move real funds.
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </AppShell>
  );
}

function AmountInput({ value, onChange }: { value: number; onChange: (v: number) => void }) {
  return (
    <div className="flex items-baseline gap-1 rounded-lg border border-ink-200 px-3 py-2.5">
      <span className="text-lg font-semibold text-ink-400">$</span>
      <input
        type="number"
        value={value}
        onChange={(e) => onChange(Number(e.target.value) || 0)}
        className="w-full bg-transparent text-lg font-semibold tabular-nums outline-none"
      />
    </div>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between">
      <span className="text-ink-400">{label}</span>
      <span className="font-medium tabular-nums text-ink-900">{value}</span>
    </div>
  );
}
