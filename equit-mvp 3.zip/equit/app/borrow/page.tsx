import { AppShell } from "@/components/layout/AppShell";
import { BorrowFlow } from "@/components/borrowing/BorrowFlow";

export default function BorrowPage() {
  return (
    <AppShell>
      <div className="mx-auto max-w-md">
        <h1 className="mb-5 text-lg font-semibold text-ink-900">Borrow</h1>
        <BorrowFlow />
      </div>
    </AppShell>
  );
}
