import { AppShell } from "@/components/layout/AppShell";
import { ScenarioSimulator } from "@/components/simulator/ScenarioSimulator";

export default function SimulatePage() {
  return (
    <AppShell>
      <div className="mx-auto max-w-2xl">
        <h1 className="text-lg font-semibold text-ink-900">
          What happens to my vault if markets move?
        </h1>
        <p className="mt-1 text-sm text-ink-500 mb-5">
          Drag each slider to model a price move and see the effect on your vault instantly.
        </p>
        <ScenarioSimulator />
      </div>
    </AppShell>
  );
}
