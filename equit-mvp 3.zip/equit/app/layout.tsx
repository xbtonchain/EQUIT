import type { Metadata } from "next";
import "./globals.css";
import { EquitWalletProvider } from "@/components/wallet/WalletProvider";

export const metadata: Metadata = {
  title: "EQUIT — Unlock liquidity without selling your stocks",
  description:
    "EQUIT turns tokenized equities into programmable collateral on Solana. Unlock liquidity, monitor risk, and protect your portfolio.",
  icons: { icon: "/favicon.svg" },
  openGraph: {
    title: "EQUIT — Unlock liquidity without selling your stocks",
    description:
      "EQUIT turns tokenized equities into programmable collateral on Solana. Unlock liquidity, monitor risk, and protect your portfolio.",
    type: "website",
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="text-ink-900 antialiased">
        <EquitWalletProvider>{children}</EquitWalletProvider>
      </body>
    </html>
  );
}
