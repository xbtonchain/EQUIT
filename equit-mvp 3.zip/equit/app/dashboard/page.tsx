"use client";

import Link from "next/link";
import { AppShell } from "@/components/layout/AppShell";
import { useRiskSnapshot, useVaultStore } from "@/store/useVaultStore";
import { VaultHealthCard } from "@/components/vault/VaultHealthCard";
import { LTVMeter } from "@/components/vault/LTVMeter";
import { HoldingsTable } from "@/components/portfolio/HoldingsTable";
import { ConcentrationWarning } from "@/components/risk/ConcentrationWarning";
import { OracleStatus } from "@/components/risk/OracleStatus";
import { DemoBadge } from "@/components/ui/Badge";
import { Button } from "@/components/ui/Button";

export default function DashboardPage() {
  const vault = useVaultStore((s) => s.vault);
  const prices = useVaultStore((s) => s.prices);
  const risk = useRiskSnapshot();

  return (
    <AppShell>
      <div className="mx-auto max-w-5xl space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm text-ink-400">Good afternoon</p>
            <h1 className="text-sm font-medium text-ink-500 mt-0.5">Your portfolio</h1>
          </div>
          {vault.isDemo && <DemoBadge />}
        </div>

        <div>
          <div className="text-4xl md:text-5xl font-semibold tabular-nums text-ink-900">
            ${risk.portfolioValue.toLocaleString(undefined, { maximumFractionDigits: 2 })}
          </div>
          <div className="mt-1 text-sm font-medium text-safe">+2.84% today</div>
        </div>

        <div className="grid gap-5 md:grid-cols-3">
          <div className="md:col-span-2 rounded-xl2 border border-ink-100 bg-white p-6 shadow-card">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium text-ink-500">Available liquidity</span>
            </div>
            <div className="mt-2 text-3xl font-semibold tabular-nums text-ink-900">
              ${risk.availableLiquidity.toLocaleString(undefined, { maximumFractionDigits: 0 })}
            </div>
            <Link href="/borrow">
              <Button className="mt-4">Unlock liquidity</Button>
            </Link>

            <div className="mt-6 grid grid-cols-3 gap-4 border-t border-ink-100 pt-5 text-sm">
              <div>
                <div className="text-xs text-ink-400">LTV</div>
                <div className="mt-0.5 font-medium tabular-nums">{(risk.ltv * 100).toFixed(0)}%</div>
              </div>
              <div>
                <div className="text-xs text-ink-400">Debt</div>
                <div className="mt-0.5 font-medium tabular-nums">${vault.debtUsdc.toLocaleString()}</div>
              </div>
              <div>
                <div className="text-xs text-ink-400">Collateral</div>
                <div className="mt-0.5 font-medium tabular-nums">
                  ${risk.portfolioValue.toLocaleString(undefined, { maximumFractionDigits: 0 })}
                </div>
              </div>
            </div>
            <div className="mt-4">
              <LTVMeter ltv={risk.ltv} maxLtv={vault.maxLtv} />
            </div>
          </div>

          <VaultHealthCard health={risk.health} />
        </div>

        {risk.concentrationWarning && <ConcentrationWarning message={risk.concentrationWarning} />}

        <div className="grid gap-5 md:grid-cols-3">
          <div className="md:col-span-2">
            <HoldingsTable holdings={vault.collateral} prices={prices} portfolioValue={risk.portfolioValue} />
          </div>
          <OracleStatus quote={prices.NVDAx} />
        </div>
      </div>
    </AppShell>
  );
}
