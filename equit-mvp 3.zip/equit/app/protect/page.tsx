import { AppShell } from "@/components/layout/AppShell";
import { AutoProtectPanel } from "@/components/protection/AutoProtectPanel";

export default function ProtectPage() {
  return (
    <AppShell>
      <div className="mx-auto max-w-md">
        <h1 className="mb-5 text-lg font-semibold text-ink-900">Protect</h1>
        <AutoProtectPanel />
      </div>
    </AppShell>
  );
}
