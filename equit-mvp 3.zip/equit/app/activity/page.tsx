"use client";

import { AppShell } from "@/components/layout/AppShell";
import { useVaultStore } from "@/store/useVaultStore";
import { ActivityList } from "@/components/activity/ActivityList";

export default function ActivityPage() {
  const activity = useVaultStore((s) => s.activity);
  return (
    <AppShell>
      <div className="mx-auto max-w-2xl">
        <h1 className="mb-5 text-lg font-semibold text-ink-900">Activity</h1>
        <ActivityList items={activity} />
      </div>
    </AppShell>
  );
}
