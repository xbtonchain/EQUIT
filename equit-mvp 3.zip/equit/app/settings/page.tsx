"use client";

import { AppShell } from "@/components/layout/AppShell";
import { useWallet } from "@solana/wallet-adapter-react";
import { SOLANA_NETWORK } from "@/components/wallet/WalletProvider";
import { useVaultStore } from "@/store/useVaultStore";

export default function SettingsPage() {
  const { publicKey, connected } = useWallet();
  const vault = useVaultStore((s) => s.vault);

  return (
    <AppShell>
      <div className="mx-auto max-w-md space-y-6">
        <h1 className="text-lg font-semibold text-ink-900">Settings</h1>

        <div className="rounded-xl2 border border-ink-100 bg-white p-5 shadow-card space-y-3 text-sm">
          <Row label="Network" value={SOLANA_NETWORK === "devnet" ? "Solana Devnet" : "Solana Mainnet"} />
          <Row label="Wallet" value={connected && publicKey ? publicKey.toBase58() : "Not connected"} />
          <Row label="Mode" value={vault.isDemo ? "Demo protocol environment" : "Live"} />
        </div>

        <div className="rounded-xl2 border border-ink-100 bg-white p-5 shadow-card space-y-3 text-sm">
          <Row label="Maximum LTV" value={`${(vault.maxLtv * 100).toFixed(0)}%`} />
          <Row
            label="Auto-Protect"
            value={vault.protection.enabled ? `On (trigger ${vault.protection.triggerHealth})` : "Off"}
          />
        </div>

        <p className="text-xs text-ink-400">
          EQUIT is a hackathon MVP. It does not offer guaranteed protection, guaranteed returns, or
          risk-free borrowing, and is not a regulated lending product.
        </p>
      </div>
    </AppShell>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between">
      <span className="text-ink-400">{label}</span>
      <span className="font-medium text-ink-900 truncate max-w-[60%] text-right">{value}</span>
    </div>
  );
}
