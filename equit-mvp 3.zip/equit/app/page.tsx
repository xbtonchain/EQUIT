import Link from "next/link";
import { LogoWordmark } from "@/components/ui/Logo";

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-white">
      <header className="mx-auto flex max-w-5xl items-center justify-between px-6 py-6">
        <LogoWordmark />
        <Link
          href="/dashboard"
          className="rounded-full bg-ink-900 px-4 py-2 text-sm font-medium text-white hover:bg-ink-800"
        >
          Launch EQUIT
        </Link>
      </header>

      <main className="mx-auto max-w-3xl px-6 pt-16 pb-24 text-center">
        <h1 className="text-4xl md:text-6xl font-semibold tracking-tight text-ink-900 leading-tight">
          Unlock liquidity without
          <br /> selling your stocks.
        </h1>
        <p className="mt-6 text-lg text-ink-500 max-w-xl mx-auto">
          EQUIT turns tokenized equities into programmable collateral. Borrow against your
          portfolio, monitor your risk, and protect your position — all on Solana.
        </p>

        <div className="mt-10 flex items-center justify-center gap-3">
          <Link
            href="/dashboard"
            className="rounded-full bg-brand-600 px-6 py-3.5 text-base font-medium text-white hover:bg-brand-700 transition-colors"
          >
            Launch EQUIT
          </Link>
          <Link
            href="/dashboard"
            className="rounded-full bg-ink-100 px-6 py-3.5 text-base font-medium text-ink-900 hover:bg-ink-200 transition-colors"
          >
            Explore demo
          </Link>
        </div>

        <div className="mt-20 flex items-center justify-center gap-3 text-sm text-ink-400">
          <span className="rounded-full border border-ink-200 px-3 py-1.5">Your portfolio</span>
          <span>→</span>
          <span className="rounded-full border border-ink-200 px-3 py-1.5">Collateral</span>
          <span>→</span>
          <span className="rounded-full border border-ink-200 px-3 py-1.5">Liquidity</span>
          <span>→</span>
          <span className="rounded-full border border-ink-200 px-3 py-1.5">Protection</span>
        </div>
      </main>
    </div>
  );
}
