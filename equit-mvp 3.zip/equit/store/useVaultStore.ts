"use client";

import { create } from "zustand";
import {
  ActivityItem,
  AssetTicker,
  MarketStatus,
  PriceQuote,
  ProtectionRules,
  VaultState,
} from "@/lib/types";
import {
  buildDemoMarketStatuses,
  buildDemoPrices,
  demoActivity,
  demoDebtUsdc,
  demoHoldings,
  demoMaxLtv,
  demoProtection,
} from "@/lib/demo/fixtures";
import { getPriceQuotes } from "@/lib/pyth/priceService";
import * as vaultService from "@/lib/vault/vaultService";
import { runRiskEngine } from "@/lib/risk/riskEngine";

interface VaultStore {
  vault: VaultState;
  prices: Record<AssetTicker, PriceQuote>;
  marketStatuses: Record<AssetTicker, MarketStatus>;
  activity: ActivityItem[];
  priceOverrides: Partial<Record<AssetTicker, number>>; // used by simulator
  lastError: string | null;
  lastToast: string | null;

  refreshPrices: () => Promise<void>;
  setPriceOverride: (ticker: AssetTicker, price: number | null) => void;
  clearPriceOverrides: () => void;
  borrow: (amountUsdc: number) => void;
  repay: (amountUsdc: number) => void;
  withdraw: (ticker: AssetTicker, usdcValue: number) => void;
  setProtection: (rules: ProtectionRules) => void;
  checkAndTriggerProtection: () => void;
  clearError: () => void;
  clearToast: () => void;
}

function effectivePrices(
  base: Record<AssetTicker, PriceQuote>,
  overrides: Partial<Record<AssetTicker, number>>
): Record<AssetTicker, PriceQuote> {
  const out = { ...base };
  (Object.keys(overrides) as AssetTicker[]).forEach((t) => {
    const override = overrides[t];
    if (override !== undefined && out[t]) {
      out[t] = { ...out[t], price: override };
    }
  });
  return out;
}

export const useVaultStore = create<VaultStore>((set, get) => ({
  vault: {
    owner: "demo",
    debtUsdc: demoDebtUsdc,
    collateral: demoHoldings,
    maxLtv: demoMaxLtv,
    protection: demoProtection,
    isDemo: true,
  },
  prices: buildDemoPrices(),
  marketStatuses: buildDemoMarketStatuses(),
  activity: demoActivity,
  priceOverrides: {},
  lastError: null,
  lastToast: null,

  refreshPrices: async () => {
    const tickers = Object.keys(buildDemoPrices()) as AssetTicker[];
    const quotes = await getPriceQuotes(tickers);
    set({ prices: quotes });
  },

  setPriceOverride: (ticker, price) =>
    set((s) => ({
      priceOverrides: { ...s.priceOverrides, [ticker]: price === null ? undefined : price },
    })),

  clearPriceOverrides: () => set({ priceOverrides: {} }),

  borrow: (amountUsdc) => {
    const s = get();
    const prices = effectivePrices(s.prices, s.priceOverrides);
    const result = vaultService.borrow(s.vault, amountUsdc, {
      prices,
      marketStatuses: s.marketStatuses,
    });
    if (!result.ok || !result.vault) {
      set({ lastError: result.error ?? "Transaction failed." });
      return;
    }
    set({
      vault: result.vault,
      lastError: null,
      lastToast: "Borrow confirmed ✓",
      activity: [
        {
          id: `act-${Date.now()}`,
          type: "borrow",
          label: "Borrowed",
          amountLabel: `+$${amountUsdc.toLocaleString()} USDC`,
          timestamp: "Just now",
          isDemo: true,
        },
        ...s.activity,
      ],
    });
  },

  repay: (amountUsdc) => {
    const s = get();
    const result = vaultService.repay(s.vault, amountUsdc);
    if (!result.ok || !result.vault) {
      set({ lastError: result.error ?? "Transaction failed." });
      return;
    }
    set({
      vault: result.vault,
      lastError: null,
      lastToast: "Repayment confirmed ✓",
      activity: [
        {
          id: `act-${Date.now()}`,
          type: "repay",
          label: "Repayment",
          amountLabel: `-$${amountUsdc.toLocaleString()} USDC`,
          timestamp: "Just now",
          isDemo: true,
        },
        ...s.activity,
      ],
    });
  },

  withdraw: (ticker, usdcValue) => {
    const s = get();
    const prices = effectivePrices(s.prices, s.priceOverrides);
    const result = vaultService.withdraw(s.vault, ticker, usdcValue, {
      prices,
      marketStatuses: s.marketStatuses,
    });
    if (!result.ok || !result.vault) {
      set({ lastError: result.error ?? "Transaction failed." });
      return;
    }
    set({
      vault: result.vault,
      lastError: null,
      lastToast: "Withdrawal confirmed ✓",
      activity: [
        {
          id: `act-${Date.now()}`,
          type: "withdraw",
          label: "Withdrawn",
          amountLabel: `$${usdcValue.toLocaleString()} ${ticker}`,
          timestamp: "Just now",
          isDemo: true,
        },
        ...s.activity,
      ],
    });
  },

  setProtection: (rules) => {
    const s = get();
    const result = vaultService.setProtection(s.vault, rules);
    if (!result.vault) return;
    set({
      vault: result.vault,
      lastToast: rules.enabled ? "Protection enabled ✓" : "Protection disabled",
      activity: rules.enabled
        ? [
            {
              id: `act-${Date.now()}`,
              type: "protection_enabled",
              label: "Auto-Protect enabled",
              amountLabel: `Trigger ${rules.triggerHealth} → Target ${rules.targetHealth}`,
              timestamp: "Just now",
              isDemo: true,
            },
            ...s.activity,
          ]
        : s.activity,
    });
  },

  checkAndTriggerProtection: () => {
    const s = get();
    const prices = effectivePrices(s.prices, s.priceOverrides);
    const result = vaultService.simulateProtectionTrigger(s.vault, {
      prices,
      marketStatuses: s.marketStatuses,
    });
    if (!result.triggered) return;
    set({
      vault: { ...s.vault, debtUsdc: result.newDebtUsdc },
      lastToast: result.note,
      activity: [
        {
          id: `act-${Date.now()}`,
          type: "protection_triggered",
          label: "Protection triggered",
          amountLabel: `Debt reduced to $${result.newDebtUsdc.toLocaleString()}`,
          timestamp: "Just now",
          isDemo: true,
        },
        ...s.activity,
      ],
    });
  },

  clearError: () => set({ lastError: null }),
  clearToast: () => set({ lastToast: null }),
}));

export function useRiskSnapshot() {
  const vault = useVaultStore((s) => s.vault);
  const prices = useVaultStore((s) => s.prices);
  const overrides = useVaultStore((s) => s.priceOverrides);
  const marketStatuses = useVaultStore((s) => s.marketStatuses);
  const effective = effectivePrices(prices, overrides);
  return runRiskEngine({
    holdings: vault.collateral,
    prices: effective,
    debtUsdc: vault.debtUsdc,
    maxLtv: vault.maxLtv,
    marketStatuses,
  });
}
